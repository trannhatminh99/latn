# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.8.7](https://github.com/trungnghia112/frontend-seed-4/compare/v1.8.6...v1.8.7) (2020-07-12)

### [1.8.6](https://github.com/trungnghia112/frontend-seed-4/compare/v1.8.5...v1.8.6) (2020-05-19)

### [1.8.5](https://github.com/trungnghia112/frontend-seed-4/compare/v1.8.2...v1.8.5) (2020-03-17)

### [1.8.4](https://github.com/trungnghia112/frontend-seed-4/compare/v1.8.2...v1.8.4) (2019-10-22)

### [1.8.3](https://github.com/trungnghia112/frontend-seed-4/compare/v1.8.2...v1.8.3) (2019-10-22)

### [1.8.2](https://github.com/trungnghia112/frontend-seed-4/compare/v1.8.1...v1.8.2) (2019-10-22)

## [1.8.1](https://github.com/trungnghia112/frontend-seed-4/compare/v1.7.6...v1.8.1) (2019-03-17)

# [1.8.0](https://github.com/trungnghia112/frontend-seed-4/compare/v1.7.6...v1.8.0) (2019-03-17)

## [1.7.6](https://github.com/trungnghia112/frontend-seed-4/compare/v1.7.5...v1.7.6) (2019-03-17)

## [1.7.5](https://github.com/trungnghia112/frontend-seed-4/compare/v1.7.4...v1.7.5) (2019-03-17)

<a name="1.7.4"></a>

## [1.7.4](https://github.com/trungnghia112/frontend-seed-4/compare/v1.7.3...v1.7.4) (2019-01-08)

<a name="1.7.3"></a>

## [1.7.3](https://github.com/trungnghia112/frontend-seed-4/compare/v1.7.2...v1.7.3) (2019-01-08)

<a name="1.7.2"></a>

## [1.7.2](https://github.com/trungnghia112/frontend-seed-4/compare/v1.7.1...v1.7.2) (2019-01-05)

<a name="1.6.7"></a>

## [1.6.7](https://github.com/trungnghia112/frontend-seed-4/compare/v1.6.6...v1.6.7) (2019-01-05)

<a name="1.7.1"></a>

## [1.7.1](https://github.com/trungnghia112/frontend-seed-4/compare/v1.6.6...v1.7.1) (2019-01-05)

<a name="1.6.7"></a>

## [1.6.7](https://github.com/trungnghia112/frontend-seed-4/compare/v1.6.6...v1.6.7) (2019-01-05)

<a name="1.6.6"></a>

## [1.6.6](https://github.com/trungnghia112/frontend-seed-4/compare/v1.6.5...v1.6.6) (2019-01-05)

<a name="1.6.5"></a>

## [1.6.5](https://github.com/trungnghia112/frontend-seed-4/compare/v1.6.4...v1.6.5) (2019-01-05)

<a name="1.6.4"></a>

## [1.6.4](https://github.com/trungnghia112/frontend-seed-4/compare/v1.6.3...v1.6.4) (2018-11-27)

<a name="1.6.3"></a>

## [1.6.3](https://github.com/trungnghia112/frontend-seed-4/compare/v1.6.2...v1.6.3) (2018-11-27)

<a name="1.6.2"></a>

## [1.6.2](https://github.com/trungnghia112/frontend-seed-4/compare/v1.6.1...v1.6.2) (2018-11-26)

<a name="1.6.1"></a>

## [1.6.1](https://github.com/trungnghia112/frontend-seed-4/compare/v1.5.4...v1.6.1) (2018-11-26)

<a name="1.5.4"></a>

## [1.5.4](https://github.com/trungnghia112/frontend-seed-4/compare/v1.5.1...v1.5.4) (2018-11-26)

<a name="1.5.3"></a>

## [1.5.3](https://github.com/trungnghia112/frontend-seed-4/compare/v1.5.1...v1.5.3) (2018-11-26)

<a name="1.5.2"></a>

## [1.5.2](https://github.com/trungnghia112/frontend-seed-4/compare/v1.5.1...v1.5.2) (2018-11-26)
